import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:flutter_application_2/constants/api_config.dart';
import 'package:flutter_application_2/constants/houses.dart';

class HouseListScreen extends StatefulWidget {
  @override
  _HouseState createState() => _HouseState();
}

class _HouseState extends State<HouseListScreen> {
  List<House> houses = [];
  List<House> searchedHouses = [];
  bool locationRequest = false;
  double uLat = 0.0;
  double uLong = 0.0;
  String searchInput = '';

  @override
  void initState() {
    super.initState();
    fetchHouses();
  }

  Future<void> fetchHouses() async {
    try {
      List<House> fetchedHouses = await ApiConfig.fetchHouses();
      setState(() {
        houses = fetchedHouses;
        filterHouses();
      });
    } catch (e) {
      print('Error retrieving houses: $e');
    }
  }

  void filterHouses() {
    searchedHouses = houses.where((house) {
      final searchCity =
          house.city.toLowerCase().contains(searchInput.toLowerCase());
      final searchPO =
          house.postalCode.toLowerCase().contains(searchInput.toLowerCase());
      return searchCity || searchPO;
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Houses',
          style: TextStyle(
            color: Colors.white,
            fontSize: 20.0,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: Colors.blue,
      ),
      body: Column(
        children: [
          const SizedBox(height: 10.0),
          TextField(
            onChanged: (value) {
              setState(() {
                searchInput = value;
                filterHouses();
              });
            },
            decoration: const InputDecoration(
              hintText: 'Search houses',
              prefixIcon: Icon(Icons.search),
            ),
          ),
          const SizedBox(height: 10.0),
          Expanded(
            child: ListView.builder(
              itemCount:
                  searchInput.isEmpty ? houses.length : searchedHouses.length,
              itemBuilder: (context, index) {
                final house =
                    searchInput.isEmpty ? houses[index] : searchedHouses[index];
                final distance = locationRequest
                    ? Geolocator.distanceBetween(
                        uLat,
                        uLong,
                        house.latitude,
                        house.longitude,
                      )
                    : null;
                return ListTile(
                  title: Text('${house.price}'),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Icon(Image.asset(house.bedroomsIcon)),
                        ]
                      )
                      if (locationRequest && distance != null)
                        Text('Distance: ${distance.toStringAsFixed(2)} meters'),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.blue,
        selectedItemColor: Colors.white,
        unselectedItemColor: Colors.white54,
        items: [
          BottomNavigationBarItem(
            icon: Icon(bedroomIcon),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.favorite),
            label: 'Favourites',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profile',
          ),
        ],
      ),
    );
  }
}
