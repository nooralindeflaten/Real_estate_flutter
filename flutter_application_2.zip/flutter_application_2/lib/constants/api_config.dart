import 'dart:convert';
import 'package:flutter_application_2/constants/houses.dart';
import 'package:http/http.dart' as http;

class ApiConfig {
  static const String apiUrl = 'https://intern.d-tt.nl/api/house';
  static const String apiKey = '98bww4ezuzfePCYFxJEWyszbUXc7dxRx';
  static const String houseDomain = 'https://intern.d-tt.nl';

  static Future<List<House>> fetchHouses() async {
    final response = await http
        .get(Uri.parse(apiUrl), headers: {'Authorization': 'Bearer $apiKey'});
    if (response.statusCode == 200) {
      final List<dynamic> jsonData = json.decode(response.body);

      final List<House> houses = jsonData.map((data) {
        return House(
          id: data['id'],
          imageData: '$houseDomain${data['image']}',
          price: data['price'],
          bedrooms: data['bedrooms'],
          bathrooms: data['bathrooms'],
          sizeHouse: data['size'],
          description: data['description'],
          postalCode: data['postalCode'],
          city: data['city'],
          latitude: data['latitude'],
          longitude: data['longitude'],
          dateCreated: data['dateCreated'],
          bedroomsIcon: data['Assets/Icons/ic_bed.svg'],
          bathroomsIcon: data['Assets/Icons/ic_bath.svg'],
          sizeIcon: data['Assets/Icons/ic_layers.svg'],
          distanceIcon: data['Assets/Icons/ic_location.svg'],
        );
      }).toList();

      return houses;
    } else {
      throw Exception(
          'API request failed with status code: ${response.statusCode}');
    }
  }
}
