class House {
  final int id;
  final String imageData;
  final double price;
  final int bedrooms;
  final int bathrooms;
  final double sizeHouse;
  final String description;
  final String postalCode;
  final String city;
  final double latitude;
  final double longitude;
  final String dateCreated;
  final bedroomsIcon;
  final bathroomsIcon;
  final sizeIcon;
  final String distanceIcon;

  House({
    required this.id,
    required this.imageData,
    required this.price,
    required this.bedrooms,
    required this.bathrooms,
    required this.sizeHouse,
    required this.description,
    required this.postalCode,
    required this.city,
    required this.latitude,
    required this.longitude,
    required this.dateCreated,
    // Icon path
    required this.bedroomsIcon,
    required this.bathroomsIcon,
    required this.sizeIcon,
    required this.distanceIcon,
  });
}
